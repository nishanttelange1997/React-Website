import React from 'react'

export default function About() {

  var a=10;
  var b=10;
  var c=10;

  return (
    <div className='container'>
    <div className='py-4'><h1>ABOUT PAGE</h1>
    <p className="lead">

        Lorem ipsum dolor sit amet consectetur adipisicing elit. 
        Voluptatum minima consequatur amet ipsam soluta dicta exercitationem vel aperiam.
         Sint delectus nihil consectetur iste est? Eum error iste voluptate accusamus reiciendis.
    </p>
    <p className="lead">

        Lorem ipsum dolor sit amet consectetur adipisicing elit. 
        Voluptatum minima consequatur amet ipsam soluta dicta exercitationem vel aperiam.
         Sint delectus nihil consectetur iste est? Eum error iste voluptate accusamus reiciendis.
    </p>
    

    <p className="lead">

Lorem ipsum dolor sit amet consectetur adipisicing elit. 
Voluptatum minima consequatur amet ipsam soluta dicta exercitationem vel aperiam.
 Sint delectus nihil consectetur iste est? Eum error iste voluptate accusamus reiciendis.
</p>
<p className="lead">

Lorem ipsum dolor sit amet consectetur adipisicing elit. 
Voluptatum minima consequatur amet ipsam soluta dicta exercitationem vel aperiam.
 Sint delectus nihil consectetur iste est? Eum error iste voluptate accusamus reiciendis.
</p>
    </div>
    
    <h1>{"(a+b)-c"}</h1>
        </div>
  )
}
