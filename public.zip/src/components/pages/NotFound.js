import React from "react";


function NotFound()
{
    return(
<>
<div>
    <h1 className="display-1">Ohhhh Sorry.......🤦‍♂️<br />
    Page Not Found........🤷</h1>
</div>
</>


    )
}
export default NotFound;
